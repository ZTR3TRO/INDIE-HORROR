import * as THREE from 'three';
import { CONFIG } from './config.js';
import { InputManager } from './core/input.js';
import { initWorld, scene, camera, renderer, controls, transformControls } from './core/world.js';
import { initLights, flashlight, explosionLight, ambientLight } from './scenes/lights.js';
import { initLevel, phoneMesh, pickupPhone, getHoveredDoor, toggleDoor, spawnModelForEditing, batteries, keyMesh, collidableObjects, fuseboxMesh, houseLights, laptopMesh, laptopWorldPosition, bookWorldPosition, keyWorldPosition, ritualStoneMesh, uvLampMesh, uvBloodMark, loadUVLamp, loadUVBloodMark, animateUVLamp, setUVMarkVisible } from './scenes/level.js';
import { initInventoryUI, toggleInventory, inventoryCollect, inventorySetBatteries, inventorySetFlashlightMode, inventoryHasItem, showInventoryBriefly } from './inventoryUI.js';
import { updatePlayer, debugInfo } from './core/player.js'; 
import { initUI, ui } from './ui.js';            
import { initLaptop, toggleLaptopUI } from './laptopUI.js'; 
import { initNumpad, toggleNumpadUI } from './numpadUI.js'; 
import { initBook, toggleBookUI } from './bookUI.js'; 
import { initStoneUI, showStoneUI, hideStoneUI } from './stoneUI.js';
import { createRain, animateRain, createExplosionEffect, animateExplosion } from './effects/particles.js';
import { initAudio, playSound, stopSound, updateRainVolume } from './core/audio.js';
import { DIALOGUES, playDialogueSequence } from './dialogues.js';

initWorld(); 
initLights(); 
initLevel(); 
initUI(); 
initLaptop(); 
initNumpad(); 
initBook(); 
initAudio(); 
createRain(); 
initInventoryUI();
loadUVLamp();
loadUVBloodMark();

initStoneUI(() => {
    ui.showSubtitle("Zare: '...¿Qué significa este número?'", 3000);
});

const input = new InputManager();
const clock = new THREE.Clock();

let gameState = 'START';
let stateTimer = 0;
let paranoiaTimer = 0; 

let hasKey = false;           
let batteriesCollected = 0;   
let tutorialShown = false;    
let powerOutageCall = false;      
let powerOutageAnswered = false;  
let powerRestored = false;
let isLaptopOpen = false;
let isNumpadOpen = false; 
let isBookOpen = false; 
let isStoneOpen = false;
let hasUVLamp   = false;        // tiene lámpara UV en inventario
let uvMode      = 'off';        // 'off' | 'normal' | 'uv'

let finalCallTriggered = false;
let finalCallAnswered = false;
let endingTriggered = false;

const debugDiv = document.createElement('div');
debugDiv.style.cssText = "position:fixed; top:10px; left:10px; color:lime; font-family:monospace; z-index:10000; background:rgba(0,0,0,0.7); padding:10px; pointer-events:none; font-size:12px; line-height:1.6;";
document.body.appendChild(debugDiv);

const startBtn = document.getElementById('startBtn');
if(startBtn) {
    startBtn.addEventListener('click', () => { 
        document.getElementById('menu').style.display = 'none'; 
        controls.lock(); 
        ui.setWakeOpacity(1); 
        gameState = 'WAKING_UP'; 
        stateTimer = 0; 
        playSound('lluvia');
        // Encender focos de la casa al inicio — se apagarán tras la explosión
        setTimeout(() => {
            houseLights.forEach(item => { item.light.intensity = 1.5; });
            ambientLight.intensity = CONFIG.ENV.AMBIENT_DIM;
        }, 500);
    });
}

renderer.domElement.addEventListener('click', () => {
    if ((gameState === 'PHONE_RINGING' || gameState === 'GAMEPLAY') && !controls.isLocked && !isLaptopOpen && !isNumpadOpen && !isBookOpen && !isStoneOpen) controls.lock();
    if (gameState === 'ENDING_OUTSIDE' && !controls.isLocked) {
        controls.lock();
        input.keys.flyMode = false; // ya no necesita flyMode
    }
});

function checkLineOfSight(targetPosition) {
    if (!targetPosition) return false;
    const ray = new THREE.Raycaster();
    const direction = new THREE.Vector3().subVectors(targetPosition, camera.position).normalize();
    ray.set(camera.position, direction);
    const distanceToTarget = camera.position.distanceTo(targetPosition);
    const hits = ray.intersectObjects(collidableObjects, true);
    if (hits.length > 0) {
        if (hits[0].distance < distanceToTarget - 0.3) return false;
    }
    return true;
}

const interactRay = new THREE.Raycaster();
const INTERACT_DISTANCE = 1.8;

function getInteractTarget() {
    interactRay.setFromCamera(new THREE.Vector2(0, 0), camera);
    interactRay.far = INTERACT_DISTANCE;
    const hits = interactRay.intersectObjects(collidableObjects, true);
    if (hits.length === 0) return null;
    return hits[0];
}

function animate() {
    requestAnimationFrame(animate);
    const delta = Math.min(clock.getDelta(), 0.05);

    animateRain();
    animateExplosion(delta);
    if (scene.userData.endingUpdate) scene.userData.endingUpdate(delta);

    const debugRay = new THREE.Raycaster();
    debugRay.setFromCamera(new THREE.Vector2(0, 0), camera);
    const debugHits = debugRay.intersectObject(scene, true);
    let objectName = "---";
    let objectPos = "---";
    let objectWorldPos = "---";
    if (debugHits.length > 0) {
        const hit = debugHits[0];
        objectName = hit.object.name;
        const lp = hit.object.position;
        objectPos = `${lp.x.toFixed(2)}, ${lp.y.toFixed(2)}, ${lp.z.toFixed(2)}`;
        const wp = new THREE.Vector3();
        hit.object.getWorldPosition(wp);
        objectWorldPos = `${wp.x.toFixed(2)}, ${wp.y.toFixed(2)}, ${wp.z.toFixed(2)}`;
    }

    const cp = camera.position;
    const camPos = `${cp.x.toFixed(2)}, ${cp.y.toFixed(2)}, ${cp.z.toFixed(2)}`;

    const distToLaptop = laptopWorldPosition.lengthSq() > 0 
        ? camera.position.distanceTo(laptopWorldPosition).toFixed(2) 
        : '?';

    const distToBook = bookWorldPosition && bookWorldPosition.lengthSq() > 0
        ? camera.position.distanceTo(bookWorldPosition).toFixed(2)
        : '?';

    const distToKey = keyWorldPosition && keyWorldPosition.lengthSq() > 0
        ? camera.position.distanceTo(keyWorldPosition).toFixed(2)
        : '?';

    debugDiv.innerHTML = `
        OBJETO: ${objectName}<br>
        POS LOCAL: ${objectPos}<br>
        POS MUNDO: ${objectWorldPos}<br>
        CAM: ${camPos}<br>
        LLAVE: ${hasKey} | BATERÍAS: ${batteriesCollected}/3<br>
        Estado: ${gameState}<br>
        DIST LAPTOP: ${distToLaptop} | DIST BOOK: ${distToBook} | DIST KEY: ${distToKey}
    `.trim();

    updateRainVolume(camera.position.x > CONFIG.ENV.NO_RAIN_BOX.MIN.x && camera.position.x < CONFIG.ENV.NO_RAIN_BOX.MAX.x);

    if (gameState === 'WAKING_UP') {
        stateTimer += delta;
        const progress = Math.min(stateTimer / CONFIG.TIMING.WAKE_DURATION, 1.0);
        const t = (1 - Math.cos(progress * Math.PI)) / 2; 
        camera.position.lerpVectors(CONFIG.POSITIONS.BED, CONFIG.POSITIONS.SIT, t);
        camera.quaternion.slerp(new THREE.Quaternion().setFromEuler(CONFIG.ROTATIONS.SIT), t);

        let eyeOpacity = 1.0;
        if (progress < 0.2) eyeOpacity = 1.0;        
        else if (progress < 0.3) eyeOpacity = 0.2;   
        else if (progress < 0.4) eyeOpacity = 0.8;   
        else if (progress < 0.6) eyeOpacity = 0.1;   
        else if (progress < 0.7) eyeOpacity = 0.4;   
        else eyeOpacity = 1.0 - progress;            

        if (progress >= 0.95) eyeOpacity = 0;
        ui.setWakeOpacity(eyeOpacity);
        if (progress >= 1.0) { gameState = 'PHONE_RINGING'; ui.setWakeOpacity(0); ui.showInteract(true); playSound('telefono'); }
    }

    if ((gameState === 'PHONE_RINGING' || gameState === 'IN_CALL' || gameState === 'GAMEPLAY' || gameState === 'ENDING_OUTSIDE') && !transformControls.dragging) {
        if ((controls.isLocked || input.keys.flyMode) && !isLaptopOpen && !isNumpadOpen && !isBookOpen && !isStoneOpen) updatePlayer(delta, input);
        if ((gameState === 'PHONE_RINGING' || (phoneMesh && phoneMesh.userData.isRingingAgain)) && phoneMesh && phoneMesh.visible) {
            phoneMesh.rotation.z = Math.sin(Date.now() * 0.02) * 0.1;
        }
    }

    if (gameState === 'TIME_JUMP') {
        stateTimer += delta;
        if (stateTimer > 4.0) { 
            ui.showBlackScreen(false); 
            camera.position.copy(CONFIG.POSITIONS.VIEW); 
            if(CONFIG.ROTATIONS.VIEW) camera.rotation.copy(CONFIG.ROTATIONS.VIEW); 
            gameState = 'PRE_EXPLOSION'; 
            stateTimer = 0; 
            ambientLight.intensity = CONFIG.ENV.AMBIENT_DIM; 
        }
    }

    if (gameState === 'PRE_EXPLOSION') {
        stateTimer += delta;
        if (stateTimer > CONFIG.TIMING.EXPLOSION_DELAY) { 
            gameState = 'EXPLODING'; 
            playSound('explosion'); 
            triggerExplosion(); 
        }
    }

    if (gameState === 'TRAVELING') {
        stateTimer += delta;
        const progress = Math.min(stateTimer / CONFIG.TIMING.TRAVEL_DURATION, 1.0);
        if (progress > 0.8) ui.setWakeOpacity((progress - 0.8) * 5); 
        const t = progress < .5 ? 2 * progress * progress : -1 + (4 - 2 * progress) * progress;
        camera.position.lerpVectors(CONFIG.POSITIONS.VIEW, CONFIG.POSITIONS.SPAWN, t);
        camera.quaternion.slerp(new THREE.Quaternion().setFromEuler(CONFIG.ROTATIONS.SPAWN), t);

        if (progress >= 1.0) {
            controls.lock();
            gameState = 'GAMEPLAY';
            stateTimer = 0;
            ambientLight.intensity = 0.0;
            // Apagar focos — la casa quedó sin luz tras la explosión
            houseLights.forEach(item => { item.light.intensity = 0; });
            ui.fadeOutWake(3000);
            playSound('respiracion'); 
            playSound('tinitus');     
            if (phoneMesh) phoneMesh.userData.isRingingAgain = false;
        }
    }


    if (gameState === 'GAMEPLAY') {
        stateTimer += delta;
        paranoiaTimer += delta;

        if (paranoiaTimer > 15) { 
            if (Math.random() < 0.3) { 
                const esTocando = Math.random() > 0.5;
                if (esTocando) playSound('tocando');
                else playSound('puerta_scream');
                const frases = esTocando ? DIALOGUES.PARANOIA_TOCANDO : DIALOGUES.PARANOIA_PUERTA;
                const fraseElegida = frases[Math.floor(Math.random() * frases.length)];
                setTimeout(() => { ui.showSubtitle(fraseElegida, 3000); }, 800);
            }
            paranoiaTimer = 0; 
        }

        if (!tutorialShown && stateTimer > 2.0) { ui.showSubtitle("Presiona [ F ] para la Linterna", 4000); tutorialShown = true; }
        
        if (!powerOutageCall && !powerRestored && stateTimer > 6.0) { 
            playSound('telefono'); 
            powerOutageCall = true; 
            if(phoneMesh) phoneMesh.userData.isRingingAgain = true; 
        }
    }

    renderer.render(scene, camera);
}

// --- INTERACCIÓN ---
input.actions.onInteract = () => {
    
    if (gameState === 'PHONE_RINGING') {
        if (camera.position.distanceTo(CONFIG.POSITIONS.PHONE) < 2.5) {
            ui.showInteract(false); 
            ui.showCall(true); 
            stopSound('telefono'); 
            stopSound('pasos'); 
            pickupPhone(); 
            gameState = 'IN_CALL'; 
            stateTimer = 0;
            playDialogueSequence(ui, DIALOGUES.CALL_1, () => {
                ui.showCall(false); 
                ui.showBlackScreen(true); 
                controls.unlock(); 
                gameState = 'TIME_JUMP'; 
                stateTimer = 0; 
                stopSound('pasos');
            });
        }
        return;
    }

    // ENDING: jugador abre la puerta para "tomar aire" → SCREAMER
    if (gameState === 'ENDING_OUTSIDE') {
        const door = getHoveredDoor();
        if (door && door.name === 'Door') {
            const dist = camera.position.distanceTo(door.position);
            if (dist < 2.5) {
                toggleDoor(door);
                playSound('puerta_abierta');
                setTimeout(() => { triggerScreamer(); }, 1500);
            }
        }
        return;
    }

    if (gameState === 'GAMEPLAY') {

        // 🔑 RECOGER LLAVE
        if (!hasKey && keyMesh && keyMesh.visible) {
            const distToKey = camera.position.distanceTo(keyWorldPosition);
            if (distToKey < 3.0) {
                const cameraDir = new THREE.Vector3();
                camera.getWorldDirection(cameraDir);
                const toKey = new THREE.Vector3().subVectors(keyWorldPosition, camera.position).normalize();
                if (cameraDir.dot(toKey) > 0.6) {
                    keyMesh.visible = false; 
                    hasKey = true;
                    inventoryCollect('key');
                    playSound('objeto'); 
                    ui.showSubtitle("🔑 ENCONTRASTE LA LLAVE DEL GARAJE", 4000); 
                    return;
                }
            }
        }

        // 🔋 BATERÍAS
        let batteryCollectedThisFrame = false;
        if (batteries.length > 0) {
            batteries.forEach((bat, index) => {
                if (!batteryCollectedThisFrame && bat.visible && !bat.userData.collected) {
                    const batWorldPos = new THREE.Vector3();
                    bat.getWorldPosition(batWorldPos);
                    const distToBat = camera.position.distanceTo(batWorldPos);
                    if (distToBat < 3.0) {
                        const cameraDir = new THREE.Vector3();
                        camera.getWorldDirection(cameraDir);
                        const toBat = new THREE.Vector3().subVectors(batWorldPos, camera.position).normalize();
                        const dotProduct = cameraDir.dot(toBat);
                        if (dotProduct > 0.6) { 
                            bat.visible = false; 
                            bat.userData.collected = true; 
                            batteriesCollected++;
                            batteryCollectedThisFrame = true;
                            inventorySetBatteries(batteriesCollected);
                            playSound('objeto'); 
                            ui.showSubtitle(`🔋 Fusible recogido (${batteriesCollected}/3)`, 2000);
                            if (batteriesCollected === 3) {
                                setTimeout(() => {
                                    ui.showSubtitle("Zare: 'Tengo los fusibles. Iré a la caja.'", 5000);
                                }, 2000);
                            }
                        }
                    }
                }
            });
        }
        if (batteryCollectedThisFrame) return;

        // 🔵 LÁMPARA UV — pickup
        if (!hasUVLamp && uvLampMesh && uvLampMesh.visible) {
            const lampPos = new THREE.Vector3();
            uvLampMesh.getWorldPosition(lampPos);
            if (camera.position.distanceTo(lampPos) < 2.0) {
                hasUVLamp = true;
                uvLampMesh.visible = false;
                inventoryCollect('uvlamp');
                playSound('objeto');
                ui.showSubtitle("Zare: '¿Una lámpara UV? ¿Qué hace esto aquí?'", 4000);
            }
        }

        const hit = getInteractTarget();
        const hitObject = hit ? hit.object : null;
        const hitDist = hit ? hit.distance : 999;

        let hitIsBook = false;
        let hitIsDoor = false;
        let hitNode = hitObject;
        while (hitNode) {
            if (hitNode.userData.isBook) hitIsBook = true;
            if (hitNode.userData.isDoor) hitIsDoor = true;
            hitNode = hitNode.parent;
        }

        // 🪨 PIEDRAS RITUALES — raycast propio con distancia mayor
        {
            const stoneRay = new THREE.Raycaster();
            stoneRay.setFromCamera(new THREE.Vector2(0, 0), camera);
            stoneRay.far = 3.5; // más generoso para objetos en el suelo
            const stoneHits = stoneRay.intersectObjects(collidableObjects, true);
            let hitStone = null;
            for (const h of stoneHits) {
                let node = h.object;
                while (node) {
                    if (node.userData.isRitualStone !== undefined) { hitStone = node; break; }
                    node = node.parent;
                }
                if (hitStone) break;
            }
            if (hitStone) {
                if (hitStone.userData.isRitualStone) {
                    isStoneOpen = true;
                    controls.unlock();
                    showStoneUI();
                } else {
                    ui.showSubtitle("Zare: 'Solo una piedra...'", 1500);
                }
                return;
            }
        }

        // 💻 LAPTOP
        if (laptopMesh && laptopWorldPosition.lengthSq() > 0) {
            const distToLaptop = camera.position.distanceTo(laptopWorldPosition);
            if (distToLaptop < 1.5 && hitDist < INTERACT_DISTANCE) {
                let node = hitObject;
                let esLaptop = false;
                while (node) {
                    if (node === laptopMesh) { esLaptop = true; break; }
                    node = node.parent;
                }
                if (esLaptop && !isLaptopOpen) {
                    isLaptopOpen = true;
                    controls.unlock();
                    toggleLaptopUI(true);
                    const exitBtn = document.getElementById('exitLaptopBtn');
                    if (exitBtn) {
                        exitBtn.onclick = () => {
                            toggleLaptopUI(false);
                            isLaptopOpen = false;
                            controls.lock();
                        };
                    }
                    return;
                }
            }
        }

        // 📖 LIBRO
        if (hitIsBook && !hitIsDoor) {
            const distToBook = bookWorldPosition && bookWorldPosition.lengthSq() > 0
                ? camera.position.distanceTo(bookWorldPosition)
                : 999;
            if (distToBook < 1.5 && !isBookOpen) {
                isBookOpen = true;
                toggleBookUI(true);
                playSound('objeto'); 
                controls.unlock(); 
            }
            return;
        }

        // 📞 SEGUNDA LLAMADA
        if (powerOutageCall && !powerOutageAnswered && phoneMesh && phoneMesh.userData.isRingingAgain && !finalCallTriggered) {
            stopSound('telefono');
            phoneMesh.userData.isRingingAgain = false; 
            powerOutageAnswered = true; 
            ui.showCall(true);
            playDialogueSequence(ui, DIALOGUES.CALL_2, () => {
                ui.showCall(false);
                ui.showSubtitle("Misión: Ve a la caja de fusibles en el GARAJE", 6000);
            });
            return;
        }

        // 📞 TERCERA LLAMADA
        if (finalCallTriggered && !finalCallAnswered && phoneMesh && phoneMesh.userData.isRingingAgain) {
            stopSound('telefono');
            phoneMesh.userData.isRingingAgain = false; 
            finalCallAnswered = true; 
            ui.showCall(true);
            playDialogueSequence(ui, DIALOGUES.CALL_FINAL, () => {
                ui.showCall(false);
                ui.showSubtitle("Misión: ¡ESCAPA POR LA PUERTA PRINCIPAL!", 6000);
            });
            return;
        }

        // ⚡ CAJA DE FUSIBLES
        if (fuseboxMesh && camera.position.distanceTo(CONFIG.POSITIONS.FUSEBOX) < 2.5 && checkLineOfSight(CONFIG.POSITIONS.FUSEBOX)) {
            if (batteriesCollected === 3) {
                if (!powerRestored) {
                    powerRestored = true;
                    ui.showSubtitle("⚡ SISTEMA REINICIADO", 3000);
                    playSound('zumbido_electrico'); 

                    houseLights.forEach(item => {
                        item.light.intensity = 1.5; 
                        if(item.mesh.material) {
                            item.mesh.material.emissive.setHex(0xffaa00);
                            item.mesh.material.emissiveIntensity = 1;
                        }
                    });
                    ambientLight.intensity = 0.05;

                    const blackoutLoop = setInterval(() => {
                        houseLights.forEach(item => {
                            if (Math.random() > 0.5) {
                                item.light.intensity = Math.random() * 2; 
                                if(item.mesh.material) item.mesh.material.emissiveIntensity = 1;
                            } else {
                                item.light.intensity = 0;
                                if(item.mesh.material) item.mesh.material.emissiveIntensity = 0;
                            }
                        });
                        if (Math.random() > 0.7) playSound('chispazo'); 
                        if (Math.random() > 0.8) houseLights.forEach(item => { item.light.intensity = 0; });
                    }, 100); 

                    setTimeout(() => {
                        clearInterval(blackoutLoop); 
                        powerRestored = false; 
                        houseLights.forEach(item => {
                            item.light.intensity = 0;
                            if(item.mesh.material) item.mesh.material.emissiveIntensity = 0;
                        });
                        ambientLight.intensity = 0;
                        stopSound('zumbido_electrico'); 
                        ui.showSubtitle("💀 El sistema colapsó por completo...", 5000);
                        setTimeout(() => {
                            playSound('telefono');
                            finalCallTriggered = true;
                            if(phoneMesh) phoneMesh.userData.isRingingAgain = true;
                        }, 5000);
                    }, 15000); 
                }
            } else {
                ui.showSubtitle(`⚠️ FALTAN FUSIBLES (${batteriesCollected}/3)`, 3000);
            }
            return;
        }

        // 🚪 PUERTAS Y CANDADOS
        const door = getHoveredDoor();
        if (door) {
            const dist = camera.position.distanceTo(door.position);
            if (dist > 2.5) return;
            
            const isGarageDoor = door.name.includes("Door_008") || door.name.includes("Door_08"); 
            const isMainDoor = door.name === "Door"; // puerta principal — nombre exacto
            console.log(`🚪 Puerta detectada: "${door.name}" | isMain: ${isMainDoor} | isGarage: ${isGarageDoor} | finalCallAnswered: ${finalCallAnswered}`);

            if (isMainDoor) {
                if (finalCallAnswered) { 
                    playSound('puerta_bloqueda'); 
                    ui.showSubtitle("Zare: '¡¿Un candado digital?! Daniel no instaló esto...'", 4000);
                    if (!isNumpadOpen) {
                        isNumpadOpen = true;
                        controls.unlock();
                        toggleNumpadUI(true);
                        setTimeout(() => {
                            ui.showSubtitle("Misión: Buscar los CÓDIGOS en la casa para escapar", 6000);
                        }, 4000);
                    }
                    return;
                } else {
                    playSound('puerta_bloqueda'); 
                    ui.showSubtitle("Zare: 'Está lloviendo demasiado fuerte, no saldré ahora.'", 3000);
                    return;
                }
            }

            if (isGarageDoor && !door.userData.isOpen) {
                if (!hasKey) { 
                    playSound('puerta_bloqueda'); 
                    ui.showSubtitle("Zare: 'Maldición, tiene candado... necesito buscar la llave.'", 4000); 
                    setTimeout(() => {
                        ui.showSubtitle("Misión: Buscar LLAVE en la casa para abrir el GARAJE", 5000);
                    }, 4000);
                    return; 
                } else { 
                    ui.showSubtitle("🔓 Abriendo con la llave...", 2000); 
                }
            }

            toggleDoor(door); 
            return;
        }
    }
};

input.actions.onMakerSpawn = () => {
    controls.unlock();
    const model = prompt("1: Fusibles, 2: Teléfono, 3: Batería, 4: Llave, 5: Laptop");
    if (model === "1") spawnModelForEditing('assets/models/caja_fusibles.glb');
    if (model === "2") spawnModelForEditing('assets/models/phone.glb');
    if (model === "3") spawnModelForEditing('assets/models/bateria_1.glb');
    if (model === "4") spawnModelForEditing('assets/models/llave.glb');
    if (model === "5") spawnModelForEditing('assets/models/laptop.glb'); 
};

// DEV: tecla B — toggle selección de uvBloodMark con TransformControls
let uvMarkEditing = false;
document.addEventListener('keydown', (e) => {
    if (e.code !== 'KeyB' || !uvBloodMark) return;
    if (!uvMarkEditing) {
        // Seleccionar
        uvMarkEditing = true;
        uvBloodMark.material.opacity = 0.8;
        uvBloodMark.scale.set(0.30, 0.30, 0.30); // restaurar scale correcto
        transformControls.attach(uvBloodMark);
        controls.unlock();
        console.log('🩸 uvBloodMark seleccionado. T=mover R=rotar. B para soltar.');
    } else {
        // Soltar
        uvMarkEditing = false;
        transformControls.detach();
        uvBloodMark.material.opacity = 0;
        console.log('🩸 uvBloodMark soltado.');
    }
});

input.actions.onInventory = () => { toggleInventory(); };
input.actions.onCamCapture = () => {
    console.log(`📷 POS: new THREE.Vector3(${camera.position.x.toFixed(3)}, ${camera.position.y.toFixed(3)}, ${camera.position.z.toFixed(3)})`);
    console.log(`📷 ROT: new THREE.Euler(${camera.rotation.x.toFixed(3)}, ${camera.rotation.y.toFixed(3)}, ${camera.rotation.z.toFixed(3)})`);
};

input.actions.onFlashlight = () => {
    if (gameState !== 'GAMEPLAY') return;

    // Ciclo: off → normal → UV (solo si tiene la lámpara) → off
    if (uvMode === 'off') {
        uvMode = 'normal';
        flashlight.color.setHex(0xffffff);
        flashlight.intensity = CONFIG.ENV.FLASHLIGHT_INTENSITY;
        setUVMarkVisible(false);
        inventorySetFlashlightMode('normal');
    } else if (uvMode === 'normal') {
        if (hasUVLamp) {
            uvMode = 'uv';
            flashlight.color.setHex(0x7B00FF);
            flashlight.intensity = CONFIG.ENV.FLASHLIGHT_INTENSITY * 0.8;
            setUVMarkVisible(true);
            inventorySetFlashlightMode('uv');
            // Primera vez que activa la UV — mostrar inventario brevemente
            showInventoryBriefly(2000);
        } else {
            // Sin lámpara UV — apagar directo
            uvMode = 'off';
            flashlight.intensity = 0;
            inventorySetFlashlightMode('off');
        }
    } else {
        uvMode = 'off';
        flashlight.color.setHex(0xffffff);
        flashlight.intensity = 0;
        setUVMarkVisible(false);
        inventorySetFlashlightMode('off');
    }
};
input.actions.onLightUp = () => { ambientLight.intensity += 0.05; };
input.actions.onLightDown = () => { ambientLight.intensity = Math.max(0, ambientLight.intensity - 0.05); };
input.actions.onFogUp = () => { scene.fog.density += 0.002; };
input.actions.onFogDown = () => { scene.fog.density = Math.max(0, scene.fog.density - 0.002); };

function triggerExplosion() { 
    createExplosionEffect(); let f=0; 
    const i = setInterval(() => { f++; explosionLight.intensity = f%2==0?200:0; if(f>10) { clearInterval(i); explosionLight.intensity=0; gameState='TRAVELING'; stateTimer=0; } }, 80); 
}

// --- CERRAR INTERFACES CON Q o ESC ---
document.addEventListener('keydown', (e) => {
    const key = e.key.toLowerCase();

    // DEV: C — capturar posición y rotación de la cámara
    if (e.code === 'KeyC') {
        console.log(`📷 POS: new THREE.Vector3(${camera.position.x.toFixed(3)}, ${camera.position.y.toFixed(3)}, ${camera.position.z.toFixed(3)})`);
        console.log(`📷 ROT: new THREE.Euler(${camera.rotation.x.toFixed(3)}, ${camera.rotation.y.toFixed(3)}, ${camera.rotation.z.toFixed(3)})`);
    }

    // DEV: Skip animaciones con Shift+S
    if (e.shiftKey && key === 's') {
        camera.position.copy(CONFIG.POSITIONS.SPAWN);
        if (CONFIG.ROTATIONS.SPAWN) camera.rotation.copy(CONFIG.ROTATIONS.SPAWN);
        ambientLight.intensity = 0.0;
        flashlight.intensity = CONFIG.ENV.FLASHLIGHT_INTENSITY;
        gameState = 'GAMEPLAY';
        stateTimer = 0;
        ui.setWakeOpacity(0);
        ui.showCall(false);
        ui.showBlackScreen(false);
        controls.lock();
        playSound('respiracion');
        console.log('⚡ DEV: Skip a GAMEPLAY');
        return;
    }

    // DEV: Shift+E — skip a GAMEPLAY con todo listo para poner el código
    if (e.shiftKey && key === 'e') {
        camera.position.copy(CONFIG.POSITIONS.SPAWN);
        if (CONFIG.ROTATIONS.SPAWN) camera.rotation.copy(CONFIG.ROTATIONS.SPAWN);
        ambientLight.intensity = 0.0;
        flashlight.intensity = CONFIG.ENV.FLASHLIGHT_INTENSITY;
        gameState = 'GAMEPLAY';
        stateTimer = 0;
        hasKey = true;
        batteriesCollected = 3;
        powerOutageCall = true;
        powerOutageAnswered = true;
        finalCallTriggered = true;
        finalCallAnswered = true;  // puerta principal desbloqueada
        ui.setWakeOpacity(0);
        ui.showCall(false);
        ui.showBlackScreen(false);
        controls.lock();
        playSound('respiracion');
        console.log('⚡ DEV: Skip — ve a la puerta y pon el código');
        return;
    }

    // DEV: Shift+E — skip directo al ending (simula numpadSuccess)
    if (e.shiftKey && key === 'e') {
        hasKey = true;
        batteriesCollected = 3;
        finalCallTriggered = true;
        finalCallAnswered = true;
        flashlight.intensity = CONFIG.ENV.FLASHLIGHT_INTENSITY;
        playSound('respiracion');
        document.dispatchEvent(new Event('numpadSuccess'));
        console.log('⚡ DEV: Skip a ENDING');
        return;
    }

    if (key === 'q' || e.key === 'Escape') {
        if (isLaptopOpen) {
            toggleLaptopUI(false);
            isLaptopOpen = false;
            setTimeout(() => { controls.lock(); }, 10); 
        }
        if (isNumpadOpen) {
            toggleNumpadUI(false);
            isNumpadOpen = false;
            setTimeout(() => { controls.lock(); }, 10);
        }
        if (isBookOpen) { 
            toggleBookUI(false);
            isBookOpen = false;
            setTimeout(() => { 
                ui.showSubtitle("Zare: 'Tenía razón... esta casa está mal. Tengo que avisarle a Daniel.'", 5000);
            }, 500); 
            setTimeout(() => { controls.lock(); }, 10);
        }
        if (isStoneOpen) {
            hideStoneUI();
            isStoneOpen = false;
            setTimeout(() => { controls.lock(); }, 10);
        }
    }
});

// ── ENDING: numpad correcto ─────────────────────────────────
document.addEventListener('numpadSuccess', () => {
    if (endingTriggered) return;
    endingTriggered = true;

    toggleNumpadUI(false);
    isNumpadOpen = false;
    controls.unlock();
    gameState = 'ENDING_CINEMATIC';

    // Posiciones exactas sacadas del editor
    const camStart = new THREE.Vector3(2.01, 2.11, -3.40); // estática mirando puerta
    const camEnd   = new THREE.Vector3(2.09, 2.11, -1.63); // avance suave hacia afuera

    // Punto B capturado con editor — inicio desde posición actual del jugador
    const posA = camera.position.clone();   // desde donde está el jugador
    const rotA = camera.rotation.clone();   // rotación actual del jugador
    const posB = new THREE.Vector3(2.041, 2.106, -0.373);
    const rotB = new THREE.Euler(-3.118, -0.034, -3.141); // mirando afuera
    const rotC = new THREE.Euler(-3.118, 0.65, -3.141);   // giro más pronunciado en B

    const WAIT_A   = 3.0;  // segundos estático en A (donde está el jugador)
    const TRAVEL   = 5.0;  // segundos viajando de A a B
    const WAIT_B   = 4.0;  // segundos en B viendo el exterior + diálogo
    const blackoutTime = (WAIT_A + TRAVEL + WAIT_B) * 1000;

    // ── FASE 2: Puerta se abre a los 1.5s + postes de luz se encienden ──
    setTimeout(() => {
        const mainDoor = scene.getObjectByName('Door');
        if (mainDoor) toggleDoor(mainDoor);
        playSound('puerta_abierta');

        // Postes — coordenadas base conocidas, foco está ~5.5 unidades arriba
        const LAMP_DATA = [
            { name: 'Lamppost_3',    pos: new THREE.Vector3( 17.82, 6.5,  31.78) },
            { name: 'Lamppost009_3', pos: new THREE.Vector3(-14.14, 6.5,  53.43) },
            { name: 'Lamppost001_3', pos: new THREE.Vector3(-50.86, 6.5,  34.37) },
            { name: 'Lamppost010_3', pos: new THREE.Vector3(-50.60, 6.5,  53.43) },
        ];
        LAMP_DATA.forEach(({ name, pos }) => {
            const lamp = scene.getObjectByName(name);
            if (lamp && lamp.isMesh && lamp.material) {
                // Emissive en el foco — solo este mesh se ve amarillo
                lamp.material = lamp.material.clone();
                lamp.material.emissive = new THREE.Color(0xffcc44);
                lamp.material.emissiveIntensity = 3.0;
            }
            // Eliminar luz anterior si existe y crear nueva en posición correcta
            const existing = scene.getObjectByName('lampLight_' + name);
            if (existing) scene.remove(existing);
            const pt = new THREE.PointLight(0xffcc44, 8.0, 60);
            pt.castShadow = false;
            pt.name = 'lampLight_' + name;
            pt.position.copy(pos);
            scene.add(pt);
        });
    }, 1500);

    // ── FASE 3: Avance suave de A a B + luz gradual + giro en B ──
    let moveTimer = 0;
    let lightTimer = 0;
    let lightDone = false;
    const lightStart = 1.8;
    const lightDur   = 8.0;  // luz sube lento — 8 segundos de 0 a 100
    let dialogShown = false;

    scene.userData.endingUpdate = (delta) => {
        if (gameState !== 'ENDING_CINEMATIC') { scene.userData.endingUpdate = null; return; }
        moveTimer += delta;

        // Luz gradual
        if (moveTimer >= lightStart && !lightDone) {
            lightTimer += delta;
            const lt = Math.min(lightTimer / lightDur, 1.0);
            ambientLight.intensity = lt * 0.08;
            houseLights.forEach(item => {
                item.light.intensity = lt * 1.2;
                if (item.mesh.material) {
                    item.mesh.material.emissive?.setHex(0xffaa00);
                    item.mesh.material.emissiveIntensity = lt;
                }
            });
            if (lt >= 1.0) lightDone = true;
        }

        // Avance de A a B — empieza después de WAIT_A
        if (moveTimer >= WAIT_A) {
            const elapsed = moveTimer - WAIT_A;
            const t = Math.min(elapsed / TRAVEL, 1.0);
            const ease = t < 0.5 ? 2*t*t : -1+(4-2*t)*t;
            camera.position.lerpVectors(posA, posB, ease);
            // Rotación fija durante el viaje — solo gira al llegar a B
            camera.rotation.copy(rotB);
        }

        // En punto B — giro sutil hacia el lado + diálogo
        if (moveTimer >= WAIT_A + TRAVEL) {
            const inB = moveTimer - (WAIT_A + TRAVEL);
            const giroT = Math.min(inB / 1.5, 1.0);
            const ease = giroT < 0.5 ? 2*giroT*giroT : -1+(4-2*giroT)*giroT;
            camera.rotation.y = rotB.y + (rotC.y - rotB.y) * ease;

            if (!dialogShown && inB > 0.8) {
                dialogShown = true;
                ui.showSubtitle("Zare: 'Regresó la luz... qué alivio.'", 3000);
            }
        }
    };

    // ── FASE 4: Blackout suave después de WAIT_B en el punto B ──
    setTimeout(() => {
        scene.userData.endingUpdate = null;
        stopSound('respiracion');
        stopSound('tinitus');
        // Fade a negro suave (1.5s)
        let fadeT = 0;
        const fadeIv = setInterval(() => {
            fadeT += 0.03;
            ui.setWakeOpacity(Math.min(fadeT, 1.0));
            if (fadeT >= 1.0) {
                clearInterval(fadeIv);
                houseLights.forEach(item => {
                    item.light.intensity = 0;
                    if (item.mesh.material) item.mesh.material.emissiveIntensity = 0;
                });
            }
        }, 45);
    }, blackoutTime);

    // ── FASES 5-8: Despertar y diálogos (relativo al blackout) ──
    setTimeout(() => {
        camera.position.copy(CONFIG.POSITIONS.WAKE_END);
        camera.rotation.copy(CONFIG.ROTATIONS.WAKE_END);
        flashlight.intensity = 0;
        uvMode = 'off';
        inventorySetFlashlightMode('off');
        ambientLight.intensity = 0.28;
        // Re-encender focos de la casa al despertar
        houseLights.forEach(item => { item.light.intensity = 1.5; });
        gameState = 'ENDING_WAKE';
    }, blackoutTime + 2000);

    setTimeout(() => {
        // Parpadeos cinematográficos — curva sinusoidal suave, como película
        // Cada parpadeo: baja lento, sube rápido (como un ojo real)
        const blinks = [
            { start: 0.0,  end: 0.18, dir: 'close' }, // cierra lento
            { start: 0.18, end: 0.28, dir: 'open'  }, // abre rápido
            { start: 0.32, end: 0.48, dir: 'close' }, // cierra lento
            { start: 0.48, end: 0.55, dir: 'open'  }, // abre rápido
            { start: 0.60, end: 0.80, dir: 'close' }, // cierra muy lento
            { start: 0.80, end: 1.00, dir: 'open'  }, // abre final — queda abierto
        ];
        let p = 0;
        const iv = setInterval(() => {
            p += 0.008; // muy lento — 0 a 1 en ~6 segundos
            let op = 0;
            for (const b of blinks) {
                if (p >= b.start && p <= b.end) {
                    const t = (p - b.start) / (b.end - b.start);
                    // Ease: cierre lento (ease-in), apertura rápida (ease-out)
                    op = b.dir === 'close'
                        ? t * t                        // ease-in: cierra acelerado
                        : 1.0 - (1.0 - t) * (1.0 - t); // ease-out: abre desacelerado
                    break;
                }
            }
            // Después del último blink — ojo completamente abierto
            if (p > 1.0) { clearInterval(iv); ui.setWakeOpacity(0); return; }
            ui.setWakeOpacity(op);
        }, 50);
    }, blackoutTime + 2200);

    setTimeout(() => {
        ui.showSubtitle("Zare: '...fue solo una pesadilla.'", 4000);
    }, blackoutTime + 5000);

    setTimeout(() => {
        ui.showSubtitle("Zare: 'Daniel... Daniel está aquí. Estoy en casa.'", 4500);
    }, blackoutTime + 10000);

    setTimeout(() => {
        ui.showSubtitle("Zare: 'Necesito tomar un poco de aire...'", 4000);
    }, blackoutTime + 15500);

    setTimeout(() => {
        gameState = 'ENDING_OUTSIDE';
        ui.showSubtitle("[ Ve a la puerta principal ]", 4000);
        // flyMode garantiza movimiento sin necesitar click del usuario
        input.keys.flyMode = false; // reset primero
        setTimeout(() => {
            input.keys.flyMode = true;
            console.log('✅ ENDING_OUTSIDE — flyMode activado');
        }, 100);
    }, blackoutTime + 20000);
});

function triggerScreamer() {
    // Flash blanco
    const flash = document.createElement('div');
    flash.style.cssText = 'position:fixed;inset:0;background:white;z-index:99999;opacity:0;transition:opacity 0.05s;';
    document.body.appendChild(flash);

    playSound('jumpscare');

    // Flash rápido
    flash.style.opacity = '1';
    setTimeout(() => { flash.style.opacity = '0'; }, 100);
    setTimeout(() => { flash.style.opacity = '1'; }, 200);
    setTimeout(() => { flash.style.opacity = '0'; }, 300);
    setTimeout(() => {
        flash.style.background = 'black';
        flash.style.opacity = '1';
        flash.style.transition = 'opacity 2s';
    }, 400);

    // Créditos después del negro
    setTimeout(() => {
        showCredits();
    }, 3000);
}

function showCredits() {
    const credits = document.createElement('div');
    credits.style.cssText = `
        position: fixed; inset: 0; background: black; z-index: 100000;
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        font-family: 'Courier New', monospace; color: #cc0000;
        opacity: 0; transition: opacity 3s;
    `;
    credits.innerHTML = `
        <div style="font-size:48px; letter-spacing:8px; margin-bottom:40px;">FIN</div>
        <div style="font-size:14px; color:#555; letter-spacing:4px; margin-bottom:60px;">LA CONGREGACIÓN DEL SÉPTIMO UMBRAL</div>
        <div style="font-size:12px; color:#333; letter-spacing:2px;">Un juego de</div>
        <div style="font-size:18px; color:#444; letter-spacing:4px; margin-top:10px;">ZARE</div>
        <div style="font-size:10px; color:#222; margin-top:60px; letter-spacing:2px;">Presiona R para reiniciar</div>
    `;
    document.body.appendChild(credits);
    setTimeout(() => { credits.style.opacity = '1'; }, 100);

    document.addEventListener('keydown', (e) => {
        if (e.code === 'KeyR') location.reload();
    }, { once: true });
}

animate();